name = raw_input("Enter file:")
if len(name) < 1 : name = "mbox-short.txt"
handle = open(name)
for line in handle:
    line = line.rstrip()
    if not line.startswith('From'): continue 
    words = line.split(' ') 
    time = words[5]
    piece = time.split(':')
    hour = piece[0] 

counts = dict()
for hr in hour:
    counts[hr] = counts.get(hr,0) +1
print counts
    
